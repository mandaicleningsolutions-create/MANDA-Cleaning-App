MANDA Cleaning Android App — Source Project

भाषा: हिंदी
प्रकार: Android Studio project source
सुविधाएँ: लोगो, घर/ऑफिस/सोफा/किचन/बाथरूम क्लीनिंग, सोलर पैनल क्लीनिंग, वॉटर टैंक क्लीनिंग, बुकिंग फॉर्म, WhatsApp बुकिंग (9404381255), कॉल बटन, UPI भुगतान के लिए intent integration placeholder.

महत्वपूर्ण:
- यह ZIP Android Studio में खोलने के लिए source project है, तैयार APK नहीं।
- APK बनाने के लिए Android Studio में project खोलकर Gradle sync करें और Build > Build APK(s) चुनें।
- UPI भुगतान विकल्प में UPI ID ms memitra429help-3@okaxis (बिना स्पेस: msmemitra429help-3@okaxis) सेट किया गया है। रिलीज़ से पहले UPI ID को UPI ऐप में सत्यापित करें और छोटी टेस्ट पेमेंट से जाँचें। भुगतान पूरा होने की पुष्टि ऐप अपने आप नहीं करता; ग्राहक को UPI ऐप में भुगतान की स्थिति देखनी होगी।
- वास्तविक payment gateway/ऑनलाइन कार्ड पेमेंट के लिए Razorpay/अन्य payment provider का merchant account, backend और verification आवश्यक है।
- इस नमूने में बुकिंग WhatsApp संदेश के रूप में जाती है; यह डेटाबेस में बुकिंग सेव नहीं करता।
