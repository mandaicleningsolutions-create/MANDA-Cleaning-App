package com.manda.cleaning;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    final String phone = "919404381255";
    final int pink = Color.rgb(213,0,88), blue = Color.rgb(7,59,131);
    EditText name, mobile, address, details, amount;
    Spinner service;
    String[] services = {"घर की सफाई", "सोफा / फर्नीचर क्लीनिंग", "खिड़की और कांच की सफाई", "ऑफिस / दुकान की सफाई", "किचन / बाथरूम क्लीनिंग", "सोलर पैनल क्लीनिंग", "वॉटर टैंक क्लीनिंग", "अन्य सफाई सेवा"};

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(6)); return t;
    }
    EditText input(String hint, boolean multi) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(16);
        e.setSingleLine(!multi); e.setPadding(dp(12), dp(8), dp(12), dp(8));
        if (multi) e.setMinLines(2);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(4), 0, dp(8));
        e.setLayoutParams(p); return e;
    }
    Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(6), 0, dp(6)); b.setLayoutParams(p); return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.rgb(246,248,253));
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(18),dp(14),dp(18),dp(24));
        scroll.addView(page); setContentView(scroll);

        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.manda_logo); logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(210)); lp.gravity = Gravity.CENTER; logo.setLayoutParams(lp); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        page.addView(logo);
        TextView title = text("MANDA-ई DOORSTEP CLEANING SOLUTIONS", 21, pink, true); title.setGravity(Gravity.CENTER); page.addView(title);
        TextView subtitle = text("आपके दरवाज़े तक सफाई सेवा", 17, blue, true); subtitle.setGravity(Gravity.CENTER); page.addView(subtitle);
        page.addView(text("हमारी सेवाएँ", 20, blue, true));
        page.addView(text("🧹 घर की सफाई  •  🛋️ सोफा/फर्नीचर  •  🪟 कांच/खिड़की  •  🏢 ऑफिस/दुकान  •  🧽 किचन/बाथरूम  •  ☀️ सोलर पैनल  •  🚰 वॉटर टैंक", 15, Color.DKGRAY, false));
        page.addView(text("बुकिंग फॉर्म", 20, blue, true));
        name = input("आपका नाम *", false); page.addView(name);
        mobile = input("मोबाइल नंबर *", false); mobile.setInputType(InputType.TYPE_CLASS_PHONE); page.addView(mobile);
        service = new Spinner(this); service.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, services));
        page.addView(text("सेवा चुनें", 15, Color.DKGRAY, true)); page.addView(service);
        address = input("पूरा पता / क्षेत्र *", true); page.addView(address);
        details = input("अतिरिक्त जानकारी (वैकल्पिक)", true); page.addView(details);
        amount = input("भुगतान राशि ₹ (बुकिंग से पहले ग्राहक से तय करें)", false); amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); page.addView(amount);
        TextView disclaimer = text("नोट: यह प्रारंभिक ऐप है। भुगतान राशि और सेवा पहले व्यवसाय द्वारा ग्राहक से पुष्टि की जानी चाहिए।", 13, Color.GRAY, false); page.addView(disclaimer);

        Button book = button("WhatsApp पर बुकिंग भेजें", pink); page.addView(book);
        book.setOnClickListener(v -> {
            String n = name.getText().toString().trim(), m = mobile.getText().toString().trim(), a = address.getText().toString().trim();
            if(n.isEmpty() || m.isEmpty() || a.isEmpty()) { Toast.makeText(this, "कृपया नाम, मोबाइल और पता भरें।", Toast.LENGTH_LONG).show(); return; }
            String msg = "नई क्लीनिंग बुकिंग%0Aनाम: "+enc(n)+"%0Aमोबाइल: "+enc(m)+"%0Aसेवा: "+enc(services[service.getSelectedItemPosition()])+"%0Aपता: "+enc(a)+"%0Aराशि: ₹"+enc(amount.getText().toString().trim().isEmpty()?"बाद में तय करें":amount.getText().toString().trim())+"%0Aजानकारी: "+enc(details.getText().toString().trim());
            openUrl("https://wa.me/"+phone+"?text="+msg);
        });
        Button pay = button("UPI ऐप से भुगतान करें", blue); page.addView(pay);
        pay.setOnClickListener(v -> {
            String amt = amount.getText().toString().trim();
            if(amt.isEmpty() || amt.equals("0")) { Toast.makeText(this, "पहले व्यवसाय से भुगतान राशि तय करें और भरें।", Toast.LENGTH_LONG).show(); return; }
            // Replace the placeholder UPI ID with the business's verified UPI ID before publishing.
            String upiId = "msmemitra429help-3@okaxis";
            if(upiId.isEmpty() || upiId.startsWith("REPLACE")) {
                new android.app.AlertDialog.Builder(this).setTitle("UPI सेटअप बाकी है")
                  .setMessage("ऑनलाइन भुगतान चालू करने के लिए व्यवसाय का सही UPI ID (उदा. name@upi) जोड़ना जरूरी है। अभी भुगतान बटन सुरक्षित रूप से बंद है।")
                  .setPositiveButton("ठीक है", null).show();
                return;
            }
            Uri uri = Uri.parse("upi://pay").buildUpon().appendQueryParameter("pa", upiId)
                .appendQueryParameter("pn", "MANDA Cleaning").appendQueryParameter("am", amt)
                .appendQueryParameter("cu", "INR").appendQueryParameter("tn", "Cleaning service booking").build();
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch(Exception ex) { Toast.makeText(this, "इस फोन में UPI ऐप नहीं मिला।", Toast.LENGTH_LONG).show(); }
        });
        Button call = button("कॉल करें: 9404381255", Color.rgb(22,138,66)); page.addView(call);
        call.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9404381255"))));
        TextView foot = text("MANDA-ई Doorstep Cleaning Solutions • 9404381255", 13, Color.GRAY, false); foot.setGravity(Gravity.CENTER); page.addView(foot);
    }
    String enc(String s) { try { return java.net.URLEncoder.encode(s, "UTF-8"); } catch(Exception e) { return s; } }
    void openUrl(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e) { Toast.makeText(this, "लिंक नहीं खुला।", Toast.LENGTH_LONG).show(); } }
}
